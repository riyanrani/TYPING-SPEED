import random
from tkinter import *
from tkinter import messagebox
import pygame

def labelSlider():
    global count, sliderwords
    text = "Welcome to Typing Speed Increaser Game"
    if count >= len(text):
        count, sliderwords = 0, ''
    sliderwords += text[count]
    count += 1
    fontLabel.config(text=sliderwords)
    fontLabel.after(150, labelSlider)

def time():
    global timeleft, score, miss, total
    if timeleft <= 0:
        gamePlayDetailLabel.config(text=f'Hit = {score} | Miss = {miss} | Total Score = {score - miss}')
        total = score / (total_time / 60)
        speedLabel.config(text=f'Typing Speed in WPM = {total:.2f}')
        if miss > 0:
            messagebox.showinfo("Misspelled Words", "Misspelled Words: " + ", ".join(missed_words))
        if messagebox.askretrycancel('Notification', 'Play Again?'):
            reset_game()
    else:
        if timeleft <= 5:
            timeLabelCount.config(fg='red')
        timeleft -= 1
        timeLabelCount.config(text=timeleft)
        timeLabelCount.after(1000, time)

def startGame(event):
    global score, miss
    if timeleft == total_time:
        time()
    gamePlayDetailLabel.config(text='')
    if wordEntry.get() == wordLabel['text']:
        score += 1
        scoreLabelCount.config(text=score)
        pygame.mixer.Sound('correct.mp3').play()  # Correct input sound
    else:
        miss += 1
        missed_words.append(wordLabel['text'])
        pygame.mixer.Sound('incorrect.mp3').play()  # Incorrect input sound
    wordLabel.config(text=random.choice(words))
    wordEntry.delete(0, END)

def reset_game():
    global score, timeleft, miss, missed_words
    score, timeleft, miss = 0, total_time, 0
    missed_words = []
    timeLabelCount.config(text=timeleft)
    wordLabel.config(text=random.choice(words))
    scoreLabelCount.config(text=score)

# Initialize pygame mixer
pygame.mixer.init()

root = Tk()
root.geometry("900x500")
root.configure(bg="#2e3f4f")
root.title("Typing Speed Increaser Game")

total_time, score, timeleft, count, sliderwords, miss = 60, 0, 60, 0, '', 0
words = ['mango', 'orange', 'hello', 'banana', 'indore', 'hospital', 'python', 'java', 'jamghat', 'ratlam', 'cow', 'yellow', 'black', 'computer', 'blue']
missed_words = []

fontLabel = Label(root, font=("arial", 20, "italic bold"), bg="#2e3f4f", fg="#ffb3ba", width=40)
fontLabel.place(x=70, y=10)
labelSlider()

wordLabel = Label(root, text=random.choice(words), font=("arial", 40, "italic bold"), bg='#2e3f4f', fg='#ffdfba')
wordLabel.place(x=300, y=200)

scoreLabel = Label(root, text="Your Score:", font=("arial", 20, "italic bold"), bg="#2e3f4f", fg='#baffc9')
scoreLabel.place(x=10, y=100)

scoreLabelCount = Label(root, text=score, font=("arial", 20, "italic bold"), bg="#2e3f4f", fg='#bae1ff')
scoreLabelCount.place(x=200, y=100)

timerLabel = Label(root, text="Time Left:", font=("arial", 20, "italic bold"), bg="#2e3f4f", fg='#ffdfba')
timerLabel.place(x=600, y=100)

timeLabelCount = Label(root, text=timeleft, font=("arial", 20, "italic bold"), bg="#2e3f4f", fg='#bae1ff')
timeLabelCount.place(x=700, y=100)

gamePlayDetailLabel = Label(root, text="Type Word and Hit Enter", font=("arial", 15, "italic bold"), bg="#2e3f4f", fg='#ffb3ba')
gamePlayDetailLabel.place(x=300, y=450)

speedLabel = Label(root, font=("arial", 20, "italic bold"), bg="#2e3f4f", fg='#ffb3ba')
speedLabel.place(x=180, y=500)

wordEntry = Entry(root, font=("arial", 20, "italic bold"), bd=5, justify="center", fg='#2e3f4f', bg='#ffdfba')
wordEntry.place(x=300, y=300)
wordEntry.focus_set()

root.bind('<Return>', startGame)
root.mainloop()

